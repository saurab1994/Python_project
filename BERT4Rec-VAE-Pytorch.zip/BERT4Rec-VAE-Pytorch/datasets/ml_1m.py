from .base import AbstractDataset
import numpy as np
import pandas as pd
import chardet
from datetime import date


class ML1MDataset(AbstractDataset):
    @classmethod
    def code(cls):
        return 'ml-1m'

    @classmethod
    def url(cls):
        return 'http://files.grouplens.org/datasets/movielens/ml-1m.zip'

    @classmethod
    def zip_file_content_is_folder(cls):
        return True

    @classmethod
    def all_raw_file_names(cls):
        return ['README',
                'movies.dat',
                'ratings.dat',
                'users.dat']
    def load_ratings_df(self):
        folder_path = self._get_rawdata_folder_path()
        file_path = folder_path.joinpath('ratings.dat')
        df = pd.read_csv(file_path, sep='::', header=None)
        df.columns = ['uid', 'sid', 'rating', 'timestamp']
        with open(folder_path.joinpath('movies.dat'), "rb") as f:
          raw_data = f.read() 
          detected_encoding = chardet.detect(raw_data)["encoding"]
        movies  = pd.read_csv(folder_path.joinpath('movies.dat'), sep="::", encoding=detected_encoding, header=None, names=["MovieID", "Title", "Genres"],engine = 'python')
        unique_genres = sorted(set(genre for genres in movies["Genres"].str.split("|") for genre in genres))
        genre_to_idx = {g: i for i, g in enumerate(unique_genres)}
        def encode_genres(genre_list):
          one_hot = np.zeros(len(unique_genres))
          for g in genre_list:
              if g in genre_to_idx:
                  one_hot[genre_to_idx[g]] = 1
          return one_hot
        movies["GenreVector"] = movies["Genres"].apply(lambda x: encode_genres(x.split("|")))
        movie_genre_vectors = dict(zip(movies["MovieID"], movies["GenreVector"]))

        return df,movie_genre_vectors


